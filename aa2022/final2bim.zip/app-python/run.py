"""
"""

def listar_planes():
    """ """
    print("Listar planes")

def crear_plan():
    """ """
    print("crear plan")

def editar_plan():
    """ """
    print("editar plan")

def eliminar_plan():
    """ """
    print("eliminar plan")



if __name__ == '__main__':
    bandera = True

    while(bandera):
        print("""Sistema de Planes de Internet """)
        print("""Opciones:\n
                1) Listar Medidores\n
                2) Crear Medidor\n
                3) Editar Medidor\n
                4) Eliminar Medidor\n""")

        opcion = int(input("Ingrese opción  :"))

        if opcion==1:
            listar_planes()
        elif opcion==2:
            crear_plan()
        elif opcion==3:
            editar_plan()
        elif opcion==4:
            eliminar_plan()
        elif opcion<1 and opcion>4:
            print("opción invalida")

        continuar = input("Ingrese la letra Y para continuar :")

        if continuar != "Y":
            bandera = False
